
//used to convert Sub-domain to mainDomain by using psl
function homePage() {
    url = window.location.origin;
    window.open(url);
}